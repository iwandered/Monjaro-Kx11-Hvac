package com.seat.hvac

import android.util.Log

class ClimateManager(private val climateThread: ClimateThreadManager.ClimateThread) {

    // 保存关闭前的状态（去掉电源状态保存）
    private var savedFanSpeed: Int = -1
    private var savedAutoFanSetting: Int = -1
    private var savedBlowingMode: Int = -1
    private var savedHvacAutoMode: Int = -1
    private var savedCirculationMode: Int = -1
    private var savedACState: Int = -1
    private var savedGCleanState: Int = -1
    private var savedTemperature: Float = 22.0f
    private var isSaved: Boolean = false

    /**
     * 设置出风模式
     */
    fun setBlowingMode(mode: Int) {
        // 使用ID常量设置
        climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_BLOWING_MODE, IdNames.SEAT_ROW_1_LEFT, mode)
        Log.d("ClimateManager", "设置出风模式: mode=$mode")
    }

    /**
     * 设置AUTO模式
     */
    fun setAuto(enable: Boolean) {
        val valInt = if (enable) 1 else 0
        climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_AUTO, valInt)
        Log.d("ClimateManager", "设置AUTO模式: enable=$enable")
    }

    /**
     * 设置AC开关
     */
    fun setAc(enable: Boolean) {
        val valInt = if (enable) 1 else 0
        climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_AC, valInt)
        Log.d("ClimateManager", "设置AC开关: enable=$enable")
    }

    /**
     * 设置内外循环
     * inner=true: 设置为内循环 (CIRCULATION_INNER)
     * inner=false: 设置为外循环 (CIRCULATION_OFF)
     */
    fun setCirculation(inner: Boolean) {
        val valInt = if (inner) IdNames.CIRCULATION_INNER else IdNames.CIRCULATION_OFF
        climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_CIRCULATION, valInt)
        Log.d("ClimateManager", "设置循环模式: ${if (inner) "内循环" else "外循环(OFF)"}")
    }

    /**
     * 设置G-Clean（净化）开关
     */
    fun setGClean(enable: Boolean) {
        val valInt = if (enable) IdNames.G_CLEAN_ON else IdNames.G_CLEAN_OFF
        climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_G_CLEAN, valInt)
        Log.d("ClimateManager", "设置G-Clean: enable=$enable")
    }

    /**
     * OFF按钮功能：只关闭AC、AUTO、净化，不关闭空调电源
     * 按照新的需求：关闭AC，关闭AUTO，关闭净化
     */
    fun turnOff() {
        // 保存当前状态（如果还未保存）
        if (!isSaved) {
            // 保存其他状态（不需要保存电源状态）
            savedFanSpeed = climateThread.getFunctionValue(IdNames.HVAC_FUNC_FAN_SPEED)
            savedAutoFanSetting = climateThread.getFunctionValue(IdNames.HVAC_FUNC_AUTO_FAN_SETTING)
            savedBlowingMode = climateThread.getFunctionValue(IdNames.HVAC_FUNC_BLOWING_MODE, IdNames.SEAT_ROW_1_LEFT)
            savedHvacAutoMode = climateThread.getFunctionValue(IdNames.HVAC_FUNC_AUTO)
            savedCirculationMode = climateThread.getFunctionValue(IdNames.HVAC_FUNC_CIRCULATION)
            savedACState = climateThread.getFunctionValue(IdNames.HVAC_FUNC_AC)
            savedGCleanState = climateThread.getFunctionValue(IdNames.HVAC_FUNC_G_CLEAN)

            // 保存当前温度
            savedTemperature = climateThread.getFunctionValueFloat(IdNames.HVAC_FUNC_TEMP_SET, IdNames.SEAT_ROW_1_LEFT)

            isSaved = true

            Log.d("ClimateManager", "保存状态: fan=$savedFanSpeed, autoFan=$savedAutoFanSetting, " +
                    "blow=$savedBlowingMode, autoMode=$savedHvacAutoMode, " +
                    "circ=$savedCirculationMode, ac=$savedACState, gclean=$savedGCleanState, temp=$savedTemperature")
        }

        try {
            // 1. 关闭AC
            setAc(false)
            Log.d("ClimateManager", "OFF: 关闭AC")

            // 2. 关闭AUTO模式
            setAuto(false)
            Log.d("ClimateManager", "OFF: 关闭AUTO模式")

            // 3. 关闭净化
            setGClean(false)
            Log.d("ClimateManager", "OFF: 关闭净化")

            // 不再关闭空调电源

        } catch (e: Exception) {
            Log.e("ClimateManager", "OFF操作失败", e)
        }
    }

    /**
     * ON按钮功能：恢复之前保存的状态（不需要打开电源）
     */
    fun turnOn() {
        if (!isSaved) {
            // 如果没有保存的状态，使用默认值
            savedFanSpeed = IdNames.FAN_SPEED_LEVEL_3
            savedAutoFanSetting = IdNames.AUTO_FAN_SETTING_NORMAL
            savedBlowingMode = IdNames.BLOWING_MODE_FACE
            savedHvacAutoMode = 0
            savedCirculationMode = IdNames.CIRCULATION_OFF
            savedACState = 0
            savedGCleanState = IdNames.G_CLEAN_OFF
            savedTemperature = 22.0f
            isSaved = true

            Log.d("ClimateManager", "使用默认状态恢复")
        }

        Log.d("ClimateManager", "恢复状态: fan=$savedFanSpeed, autoFan=$savedAutoFanSetting, " +
                "blow=$savedBlowingMode, autoMode=$savedHvacAutoMode, " +
                "circ=$savedCirculationMode, ac=$savedACState, gclean=$savedGCleanState, temp=$savedTemperature")

        try {
            // 不再打开空调电源

            // 1. 恢复温度设置
            val tempInt = (savedTemperature * 10).toInt()
            climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_TEMP_SET, IdNames.SEAT_ROW_1_LEFT, tempInt)
            Log.d("ClimateManager", "ON: 恢复温度设置: $savedTemperature")

            // 2. 恢复AC状态
            setAc(savedACState == 1)
            Log.d("ClimateManager", "ON: 恢复AC状态: ${savedACState == 1}")

            // 3. 恢复AUTO模式
            setAuto(savedHvacAutoMode == 1)
            Log.d("ClimateManager", "ON: 恢复AUTO模式: ${savedHvacAutoMode == 1}")

            // 4. 恢复循环模式
            val isInner = savedCirculationMode == IdNames.CIRCULATION_INNER
            setCirculation(isInner)
            Log.d("ClimateManager", "ON: 恢复循环模式: ${if (isInner) "内循环" else "外循环"}")

            // 5. 恢复出风模式
            setBlowingMode(savedBlowingMode)
            Log.d("ClimateManager", "ON: 恢复出风模式: $savedBlowingMode")

            // 6. 恢复风量
            if (savedHvacAutoMode == 1) {
                // 自动模式
                val autoLevel = mapAutoSettingToLevel(savedAutoFanSetting)
                val setting = when (autoLevel) {
                    1 -> IdNames.AUTO_FAN_SETTING_QUIETER
                    2 -> IdNames.AUTO_FAN_SETTING_SILENT
                    3 -> IdNames.AUTO_FAN_SETTING_NORMAL
                    4 -> IdNames.AUTO_FAN_SETTING_HIGH
                    5 -> IdNames.AUTO_FAN_SETTING_HIGHER
                    else -> IdNames.AUTO_FAN_SETTING_NORMAL
                }
                climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_AUTO_FAN_SETTING, setting)
                Log.d("ClimateManager", "ON: 恢复自动风量: 级别$autoLevel")
            } else {
                // 手动模式
                val manualLevel = mapSpeedToLevel(savedFanSpeed)
                val mappedSpeed = when(manualLevel) {
                    0 -> IdNames.FAN_SPEED_OFF
                    1 -> IdNames.FAN_SPEED_LEVEL_1
                    2 -> IdNames.FAN_SPEED_LEVEL_2
                    3 -> IdNames.FAN_SPEED_LEVEL_3
                    4 -> IdNames.FAN_SPEED_LEVEL_4
                    5 -> IdNames.FAN_SPEED_LEVEL_5
                    6 -> IdNames.FAN_SPEED_LEVEL_6
                    7 -> IdNames.FAN_SPEED_LEVEL_7
                    8 -> IdNames.FAN_SPEED_LEVEL_8
                    9 -> IdNames.FAN_SPEED_LEVEL_9
                    else -> IdNames.FAN_SPEED_OFF
                }
                climateThread.setFunctionValueChecked(IdNames.HVAC_FUNC_FAN_SPEED, mappedSpeed)
                Log.d("ClimateManager", "ON: 恢复手动风量: 级别$manualLevel")
            }

            // 7. 恢复G-Clean状态
            setGClean(savedGCleanState == IdNames.G_CLEAN_ON)
            Log.d("ClimateManager", "ON: 恢复G-Clean状态: ${savedGCleanState == IdNames.G_CLEAN_ON}")

            // 重置保存标志
            isSaved = false

            Log.d("ClimateManager", "ON: 恢复所有状态完成")

        } catch (e: Exception) {
            Log.e("ClimateManager", "ON操作失败", e)
        }
    }

    /**
     * 将自动风量常量转换为档位级别
     */
    private fun mapAutoSettingToLevel(setting: Int): Int {
        return when (setting) {
            IdNames.AUTO_FAN_SETTING_QUIETER -> 1
            IdNames.AUTO_FAN_SETTING_SILENT -> 2
            IdNames.AUTO_FAN_SETTING_NORMAL -> 3
            IdNames.AUTO_FAN_SETTING_HIGH -> 4
            IdNames.AUTO_FAN_SETTING_HIGHER -> 5
            else -> 3
        }
    }

    /**
     * 将风量常量转换为档位级别
     */
    private fun mapSpeedToLevel(speed: Int): Int {
        return when (speed) {
            IdNames.FAN_SPEED_OFF -> 0
            IdNames.FAN_SPEED_LEVEL_1 -> 1
            IdNames.FAN_SPEED_LEVEL_2 -> 2
            IdNames.FAN_SPEED_LEVEL_3 -> 3
            IdNames.FAN_SPEED_LEVEL_4 -> 4
            IdNames.FAN_SPEED_LEVEL_5 -> 5
            IdNames.FAN_SPEED_LEVEL_6 -> 6
            IdNames.FAN_SPEED_LEVEL_7 -> 7
            IdNames.FAN_SPEED_LEVEL_8 -> 8
            IdNames.FAN_SPEED_LEVEL_9 -> 9
            else -> 0
        }
    }
}